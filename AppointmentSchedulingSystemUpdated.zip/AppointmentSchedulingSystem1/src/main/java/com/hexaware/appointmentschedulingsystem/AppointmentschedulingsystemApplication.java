package com.hexaware.appointmentschedulingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class AppointmentschedulingsystemApplication {

	public static void main(String[] args)  {
		SpringApplication.run(AppointmentschedulingsystemApplication.class, args);
	}

}
